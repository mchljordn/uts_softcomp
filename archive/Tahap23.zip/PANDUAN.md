# Panduan Penggunaan Aplikasi
## Prediksi Risiko Dropout Mahasiswa — Manual, GA-Tuned, dan ANN-Tuned FIS

---

## Persyaratan Sistem

| Komponen | Versi Minimum |
|---|---|
| Python | 3.9+ |
| scikit-fuzzy | 0.4.2 |
| numpy | 1.24 |
| matplotlib | 3.7 |
| streamlit | 1.30 |
| scipy | 1.10 |
| deap | 1.3 (untuk GA) |
| tensorflow / keras | 2.12 (untuk ANN) |

---

## Instalasi

```bash
# 1. Clone / salin folder proyek
cd fis_dropout/

# 2. (Opsional) Buat virtual environment
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows

# 3. Install dependencies
pip install -r requirements.txt
```

---

## Menjalankan Aplikasi

### Cara 1 — Streamlit (Antarmuka Web)
```bash
streamlit run app-copy.py
```
Buka browser di: **http://localhost:8501**

### Cara 2 — Script Python langsung
```bash
python fis_manual.py   # Jalankan FIS manual saja
python fis_ga.py       # Jalankan FIS dengan optimasi GA
python fis_ann.py      # Jalankan FIS dengan optimasi ANN
```

---

## Perbedaan Ketiga Pendekatan FIS

| Metode | Deskripsi |
|---|---|
| **Manual FIS** | Aturan dan parameter membership function ditentukan secara manual oleh pakar |
| **GA-Tuned FIS** | Algoritma Genetika (GA) digunakan untuk mengoptimalkan parameter MF dan bobot aturan secara otomatis |
| **ANN-Tuned FIS** | Jaringan Saraf Tiruan (ANN) digunakan untuk menyetel parameter FIS berdasarkan data pelatihan |

---

## Fitur Aplikasi (Streamlit)

### Tab 1 — Prediksi
1. Pilih metode FIS yang ingin digunakan: **Manual**, **GA-Tuned**, atau **ANN-Tuned**
2. Atur nilai slider:
   - **IPK Semester** (0–4.0)
   - **Tingkat Kehadiran** (0–100%)
   - **Jumlah MK Gagal** (0–10)
   - **Status Ekonomi** (0=Rentan, 1=Stabil)
3. Klik tombol **Hitung Risiko Dropout**
4. Lihat skor, kategori, dan rekomendasi intervensi

### Tab 2 — Perbandingan Membership Functions
- Visualisasi kurva MF dari ketiga metode FIS (Manual, GA-Tuned, ANN-Tuned) secara berdampingan
- Memudahkan perbandingan bagaimana tiap metode mendefinisikan batas-batas linguistik variabel

### Tab 3 — Visualisasi GA
- Menampilkan proses evolusi GA per generasi/populasi
- Setiap individu dalam populasi diplot dan dibandingkan terhadap baseline (FIS manual)
- Memperlihatkan konvergensi nilai fitness menuju solusi optimal

### Tab 4 — Evaluasi Batch
- Klik **Jalankan Evaluasi** untuk menguji 120 sampel simulasi pada ketiga metode sekaligus
- Lihat confusion matrix dan akurasi per kelas untuk masing-masing metode
- Bandingkan performa Manual vs GA-Tuned vs ANN-Tuned secara langsung

---

## Struktur File

```
fis_dropout/
├── fis_manual.py      # Core FIS: MF, Rules, Inferensi (manual)
├── fis_ga.py          # FIS dengan optimasi Algoritma Genetika
├── fis_ann.py         # FIS dengan optimasi Jaringan Saraf Tiruan
├── app.py             # Aplikasi Streamlit versi sebelumnya (jangan diubah)
├── app-copy.py        # Aplikasi Streamlit versi baru (tiga FIS)
├── requirements.txt   # Daftar library
└── PANDUAN.md         # File ini
```

---

## Interpretasi Output

| Skor Risiko | Label  | Tindakan                        |
|---|---|---|
| 0 – 39      | Rendah | Monitoring rutin                 |
| 40 – 64     | Sedang | Konseling akademik               |
| 65 – 100    | Tinggi | Intervensi segera (dosen wali)   |

---

## Catatan Tambahan

- File `app.py` **tidak dimodifikasi** dan tetap berfungsi sebagai versi stabil sebelumnya.
- Semua pengembangan baru dilakukan di `app-copy.py`.
- Hasil optimasi GA dan ANN dapat berbeda tiap kali dijalankan tergantung inisialisasi acak; gunakan `random_seed` jika diperlukan hasil yang reproducible.
